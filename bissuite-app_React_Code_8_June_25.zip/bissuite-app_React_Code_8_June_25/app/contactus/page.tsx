import React from "react";
import Contactus from "./components/Contactus";

const page = () => {
  return (
    <>
      <Contactus />
    </>
  );
};

export default page;
