import React from "react";
import Busniessmodel from "./components/Busniessmodel";

const page = () => {
  return (
    <>
      <Busniessmodel />
    </>
  );
};

export default page;
