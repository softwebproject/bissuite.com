import React from "react";
import GigForm from "./GigForm";

const CreateGigs = () => {
  return (
    <>
      <div>
        <GigForm />
      </div>
    </>
  );
};

export default CreateGigs;
