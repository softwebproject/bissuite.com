import React from "react";
import Swotgenerate from "./components/Swotgenerate";

const page = () => {
  return (
    <>
      <Swotgenerate />
    </>
  );
};

export default page;
