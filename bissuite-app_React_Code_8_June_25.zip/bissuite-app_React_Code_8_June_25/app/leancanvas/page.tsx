import React from "react";
import Leancanvas from "./components/Leancanvas";

const page = () => {
  return (
    <>
      <Leancanvas />
    </>
  );
};

export default page;
