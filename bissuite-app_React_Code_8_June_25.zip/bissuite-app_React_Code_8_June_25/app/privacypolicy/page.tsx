import React from "react";
import PrivacyPolicyMain from "./components/privacypolicyMain";

const page = () => {
  return (
    <>
      <PrivacyPolicyMain />
    </>
  );
};

export default page;
