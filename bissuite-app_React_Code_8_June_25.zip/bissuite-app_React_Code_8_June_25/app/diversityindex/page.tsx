import React from "react";
import Diversityindex from "./components/Diversityindex";

const page = () => {
  return (
    <>
      <Diversityindex />
    </>
  );
};

export default page;
