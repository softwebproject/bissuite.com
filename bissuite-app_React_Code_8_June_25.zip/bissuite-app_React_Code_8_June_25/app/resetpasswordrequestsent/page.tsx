import ResetPasswordPage2 from "./components/ResetPasswordPage2";

const page = () => {
  return (
    <>
      <ResetPasswordPage2 />
    </>
  );
};

export default page;
