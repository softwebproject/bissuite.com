import React from "react";
import TermsandconditionHeaders from "./TermsandconditionHeaders";
import TermsandconditionFormSection from "./TermsandconditionFormSection";

const Termsandcondition = () => {
  return (
    <>
      <TermsandconditionHeaders />
      <TermsandconditionFormSection />
    </>
  );
};

export default Termsandcondition;
