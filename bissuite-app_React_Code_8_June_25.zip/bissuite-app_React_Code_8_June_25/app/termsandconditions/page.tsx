import React from "react";
import Termsandcondition from "./components/Termsandcondition";

const page = () => {
  return (
    <>
      <Termsandcondition />
    </>
  );
};

export default page;
