import ResetPasswordPage from "./components/ResetPasswordPage";

const page = () => {
  return (
    <>
      <div>
        <ResetPasswordPage />
      </div>
    </>
  );
};

export default page;
