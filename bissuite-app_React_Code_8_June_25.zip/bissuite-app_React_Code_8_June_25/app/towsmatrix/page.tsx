import React from "react";
import Towsmatrixgenerate from "./components/Towsmatrixgenerate";

const page = () => {
  return (
    <>
      <Towsmatrixgenerate />
    </>
  );
};

export default page;
