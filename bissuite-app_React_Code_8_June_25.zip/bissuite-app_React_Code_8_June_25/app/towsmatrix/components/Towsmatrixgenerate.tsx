import React from "react";
import TowsmatrixHeader from "./TowsmatrixHeaders";
import TowsmatrixFormSection from "./TowsmatrixFormSection";

const Towsmatrixgenerate = () => {
  return (
    <>
      <TowsmatrixHeader />
      <TowsmatrixFormSection />
    </>
  );
};

export default Towsmatrixgenerate;
