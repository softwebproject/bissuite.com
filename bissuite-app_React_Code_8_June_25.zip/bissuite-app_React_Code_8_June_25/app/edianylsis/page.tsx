import React from "react";
import EDIAnylsis from "./components/EDIAnylsis";

const page = () => {
  return (
    <>
      <div>
        <EDIAnylsis />
      </div>
    </>
  );
};

export default page;
