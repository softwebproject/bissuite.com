import React from "react";
import SignIn from "./components/SignIn";

const page = () => {
  return (
    <>
      <SignIn />
    </>
  );
};

export default page;
