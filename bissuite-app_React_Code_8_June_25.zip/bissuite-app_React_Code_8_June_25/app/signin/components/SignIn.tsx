import React from "react";
import SignInPage from "./SignInPage";

const SignIn = () => {
  return (
    <>
      <SignInPage />
    </>
  );
};

export default SignIn;
