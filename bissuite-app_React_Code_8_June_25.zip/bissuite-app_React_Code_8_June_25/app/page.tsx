import Home from "./Home/Home";
export default function page() {
  return (
    <>
      {/* <Navbar /> */}
      <Home />
      {/* <Footer /> */}
    </>
  );
}
