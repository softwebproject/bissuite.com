import ResetPasswordPage4 from "./components/ResetPasswordPage4";

const page = () => {
  return (
    <>
      <ResetPasswordPage4 />
    </>
  );
};

export default page;
