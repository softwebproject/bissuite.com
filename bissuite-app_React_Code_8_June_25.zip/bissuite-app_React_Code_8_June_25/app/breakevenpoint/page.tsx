import React from "react";
import Breakevenpoint from "./components/Breakevenpoint";

const page = () => {
  return (
    <>
      <Breakevenpoint />
    </>
  );
};

export default page;
