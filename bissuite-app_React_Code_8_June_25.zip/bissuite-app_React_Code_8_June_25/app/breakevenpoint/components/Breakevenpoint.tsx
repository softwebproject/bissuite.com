import React from "react";
import BreakevenHeader from "./BreakevenHeader";
import BreakevenFormSection from "./BreakevenFormSection";

const Breakevenpoint = () => {
  return (
    <>
      <BreakevenHeader />
      <BreakevenFormSection />
    </>
  );
};

export default Breakevenpoint;
