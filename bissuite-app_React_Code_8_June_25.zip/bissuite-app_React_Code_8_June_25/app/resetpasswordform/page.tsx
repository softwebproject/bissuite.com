import ResetPasswordPage3 from "./components/ResetPasswordPage3";

const page = () => {
  return (
    <>
      <ResetPasswordPage3 />
    </>
  );
};

export default page;
