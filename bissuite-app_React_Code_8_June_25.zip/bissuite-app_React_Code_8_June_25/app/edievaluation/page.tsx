import React from "react";
import EDIEvaluation from "./components/EDIEvaluation";

const page = () => {
  return (
    <>
      <div>
        <EDIEvaluation />
      </div>
    </>
  );
};

export default page;
