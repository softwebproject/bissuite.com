import React from "react";
import TowsHeader from "./TowsHeaders";
import TowsFormSection from "./TowsFormSection";

const Towsgenerate = () => {
  return (
    <>
      <TowsHeader />
      <TowsFormSection />
    </>
  );
};

export default Towsgenerate;
