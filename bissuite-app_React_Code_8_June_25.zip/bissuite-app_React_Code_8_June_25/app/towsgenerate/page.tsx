import React from "react";
import Towsgenerate from "./components/Towsgenerate";

const page = () => {
  return (
    <>
      <Towsgenerate />
    </>
  );
};

export default page;
