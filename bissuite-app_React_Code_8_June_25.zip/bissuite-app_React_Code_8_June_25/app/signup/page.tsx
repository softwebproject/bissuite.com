import React from "react";
import Signup from "./components/Signup";

const page = () => {
  return (
    <>
      <Signup />
    </>
  );
};

export default page;
