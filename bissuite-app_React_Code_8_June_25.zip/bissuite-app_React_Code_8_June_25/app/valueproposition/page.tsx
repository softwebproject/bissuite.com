import React from "react";
import Valueproposition from "./components/Valueproposition";

const page = () => {
  return (
    <>
      <Valueproposition />
    </>
  );
};

export default page;
